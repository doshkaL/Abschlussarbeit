#import os

#class Config:
   #  LDAP_SERVER = 'login-dc-01.login.htw-berlin.de'
   # LDAP_BASE_DN = 'dc=login,dc=htw-berlin,dc=de'
   #  LDAP_USER_DN = 'ou=idmusers,dc=login,dc=htw-berlin,dc=de'
   # LDAP_SEARCH_FILTER = '(uid={})'
   ## LDAP_SSL = True

#config = Config()
