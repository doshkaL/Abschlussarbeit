#from flask import Flask
##f#rom flask_sqlalchemy import SQLAlchemy
#from flask_jwt_extended import JWTManager
#from app.config import Config

#db = SQLAlchemy()
#jwt = JWTManager()

#def create_app():
 #   app = Flask(__name__)
  #  app.config.from_object(Config)
    
   # db.init_app(app)
   # jwt.init_app(app)
    
    #with app.app_context():
     #   from app import routes  # Import routes
      #  db.create_all()  # Erstellen der Datenbanktabellen
    
   # return app
