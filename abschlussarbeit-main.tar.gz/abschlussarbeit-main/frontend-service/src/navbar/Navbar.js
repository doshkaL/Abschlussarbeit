import React from 'react';
import { Link, useNavigate } from 'react-router-dom'; // useNavigate hinzufügen
import './Navbar.css';
import logo from './logo.jpg';  // Importiere dein Logo

const Navbar = () => {
  const navigate = useNavigate(); // useNavigate initialisieren

  // Funktion für den Klick auf das Benutzer-Icon
  const handleUserIconClick = () => {
    navigate('/login'); // Weiterleitung zur Login-Seite
  };
  

  return (
    <header className="header">
      <div className="navbar-container">
        {/* Logo und Titel */}
        <div className="logo-container">
          <Link to="/" className="logo-link">
            <img src={logo} alt="Logo" className="logo-image" />
          </Link>
          <div className="logo-title">
            <Link to="/" className="title-link">
              <h1 className="title">Hochschule für Technik und Wirtschaft Berlin</h1>
              <h2 className="subtitle">University of Applied Sciences</h2>
            </Link>
          </div>
        </div>

      

        {/* User-Icon */}
        <div className="profile-icon" onClick={handleUserIconClick}> {/* onClick hinzufügen */}
          <span className="material-icons user-icon">account_circle</span>  {/* Material Icons Benutzer-Icon */}
        </div>
      </div>
    </header>
  );
};

export default Navbar;