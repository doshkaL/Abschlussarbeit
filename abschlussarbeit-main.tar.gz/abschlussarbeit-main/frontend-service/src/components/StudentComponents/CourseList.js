import React from "react";
import CourseCard from "./CourseCard";

const CourseList = ({ courses, onSelect }) => {
  // Zufällige Pattern für die Karten
  const getRandomColor = () => {
    const colors = [
      // Gradient Colors
      "bg-gradient-to-r from-cyan-500 to-teal-500",
      "bg-gradient-to-bl from-purple-700 to-pink-500",
      "bg-gradient-to-br from-yellow-400 to-orange-500",
      "bg-gradient-to-tl from-green-400 to-blue-500",
    
      // Solid Colors with Opacity
      "bg-indigo-300 bg-opacity-80",
      "bg-emerald-300 bg-opacity-80",
      "bg-sky-300 bg-opacity-80",
      "bg-rose-300 bg-opacity-80",
    
      // Dark Mode Friendly Colors
      "bg-gray-800 bg-opacity-90",
      "bg-gray-700 bg-opacity-90",
      "bg-gray-600 bg-opacity-90",
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  };

  return (
    <section className="w-full max-w-6xl mx-auto p-6 bg-gray-50 rounded-lg shadow-md">
      <h3 className="text-2xl font-semibold text-gray-700 mb-6">Kursübersicht</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {courses.map((course) => (
          <CourseCard
            key={course.course_id}
            course={course}
            onSelect={onSelect}
            getRandomPattern={getRandomColor}
          />
        ))}
      </div>
    </section>
  );
};

export default CourseList;
