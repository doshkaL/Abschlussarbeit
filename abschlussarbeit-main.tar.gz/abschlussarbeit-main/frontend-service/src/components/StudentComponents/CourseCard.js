import React from "react";

const CourseCard = ({ course, onSelect, getRandomPattern }) => {
  return (
    <div
      className="flex flex-col bg-white rounded-lg shadow-lg cursor-pointer hover:shadow-xl transform transition duration-300 hover:scale-105"
      onClick={() => onSelect(course.course_id)}
    >
      <div
       className={`h-24 w-full rounded-t-lg ${getRandomPattern()}`}>

      </div>

      <div className="p-4 text-center">
        <h2 className="text-lg font-semibold text-gray-700">{course.course_name}</h2>
        
      </div>
    </div>
  );
};

export default CourseCard;
