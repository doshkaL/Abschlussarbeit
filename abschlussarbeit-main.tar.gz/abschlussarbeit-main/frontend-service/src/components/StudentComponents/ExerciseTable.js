import React from "react";

const ExerciseTable = ({ exercises ,onFeedbackClick }) => {
  // Funktion zum Extrahieren der Note aus grade_result
  const extractNote = (gradeResult) => {
    if (!gradeResult) return "Noch nicht bewertet";
    const match = gradeResult.match(/Note: ([0-9.]+)/); // Suche nach "Note: X.X"
    return match ? match[1] : "Noch nicht bewertet";
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
        <thead className="bg-gray-200 text-gray-700">
          <tr>
            <th className="px-6 py-3 text-left text-sm font-medium">Übung</th>
            <th className="px-6 py-3 text-left text-sm font-medium">Datum</th>
            <th className="px-6 py-3 text-left text-sm font-medium">Note</th>
            <th className="py-2 px-4 border">Aktionen</th>
          </tr>
        </thead>
        <tbody>
  {exercises.map((exercise, index) => (
    <tr
      key={index}
      className={`${
        index % 2 === 0 ? "bg-gray-100" : "bg-white"
      } hover:bg-gray-200`}
    >
      <td className="px-6 py-4 text-sm text-gray-800 font-medium">
        {exercise.exercise_name}
      </td>
      <td className="px-6 py-4 text-sm text-gray-600">
        {exercise.due_date || "Kein Feedback vorhanden"}
      </td>
      <td className="px-6 py-4 text-sm text-green-600 font-semibold">
      {extractNote(exercise.grade_result)} {/* Zeigt nur die Note */}
      </td>  <td className="py-2 px-4 border">
      <button
  className="text-blue-600 underline hover:text-blue-800"
  onClick={() => onFeedbackClick(exercise)}
>
  Detailliertes Feedback
</button>
              </td>
    </tr>
  ))}
</tbody>
      </table>
    </div>
  );
};

export default ExerciseTable;
