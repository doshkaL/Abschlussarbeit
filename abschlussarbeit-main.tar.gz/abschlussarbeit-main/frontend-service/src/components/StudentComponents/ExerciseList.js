import React, { useState } from "react";
import ExerciseTable from "./ExerciseTable";



const ExerciseList = ({ exercises, courseName,onFeedbackClick,onReturn }) => {
  const [sortMode, setSortMode] = useState("date"); // Standard-Sortiermodus: nach Datum

  const sortedExercises = [...exercises].sort((a, b) => {
    if (sortMode === "date") {
      return new Date(a.date) - new Date(b.date); // Nach Datum aufsteigend
    } else if (sortMode === "time") {
      return new Date(`1970-01-01T${a.time}`) - new Date(`1970-01-01T${b.time}`); // Nach Zeit aufsteigend
    }
    return 0;
  });

  return (
    <section className="w-full max-w-4xl bg-white p-6 rounded-lg shadow-xl mb-8">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-3xl font-semibold text-gray-700">
          Übungen für {courseName}
        </h3>
        <button
          className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-full shadow-md hover:shadow-lg transition-transform transform hover:-translate-y-1"
           onClick={onReturn}
          
        >
          Zurück
        </button>
      </div>
      <div className="flex justify-end mb-4">
        <label className="mr-2 text-gray-700">Sortieren nach:</label>
        <select
          value={sortMode}
          onChange={(e) => setSortMode(e.target.value)}
          className="p-2 border rounded"
        >
          <option value="date">Datum</option>
          <option value="time">Zeit</option>
        </select>
      </div>
      {sortedExercises && sortedExercises.length > 0 ? (
        <ExerciseTable exercises={sortedExercises} onFeedbackClick={onFeedbackClick} />
      ) : (
        <p className="text-gray-500">Keine Übungen vorhanden.</p>
      )}
    </section>
  );
};

export default ExerciseList;
