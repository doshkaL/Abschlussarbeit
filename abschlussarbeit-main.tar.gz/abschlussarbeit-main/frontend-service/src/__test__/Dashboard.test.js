import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom'; // für bessere Assertions
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import InstructorDashboard from './InstructorDashboard';
import StudentDashboard from './StudentDashboard';

// Mock Axios
const mock = new MockAdapter(axios);

describe('Dashboard Tests', () => {
  afterEach(() => {
    mock.reset(); // Setzt alle Mocks nach jedem Test zurück
  });

  // -----------------------------
  // Tests für InstructorDashboard
  // -----------------------------
  describe('InstructorDashboard', () => {
    it('zeigt eine Ladeanzeige während des Datenladens', async () => {
      mock
        .onGet('http://localhost:5001/instructor/courses?username=s064450330')
        .reply(200, []);

      render(<InstructorDashboard />);
      expect(screen.getByText('Daten werden geladen...')).toBeInTheDocument();

      await waitFor(() => {
        expect(screen.queryByText('Daten werden geladen...')).not.toBeInTheDocument();
      });
    });

    it('zeigt die Liste der Kurse an, nachdem die Daten geladen wurden', async () => {
      const mockCourses = [
        { course_id: 1, course_name: 'Mathematik', students: [] },
        { course_id: 2, course_name: 'Informatik', students: [] },
      ];

      mock
        .onGet('http://localhost:5001/instructor/courses?username=s064450330')
        .reply(200, mockCourses);

      render(<InstructorDashboard />);
      expect(await screen.findByText('Mathematik')).toBeInTheDocument();
      expect(await screen.findByText('Informatik')).toBeInTheDocument();
    });

    it('zeigt eine Fehlermeldung an, wenn das Laden der Daten fehlschlägt', async () => {
      mock
        .onGet('http://localhost:5001/instructor/courses?username=s064450330')
        .reply(500);

      render(<InstructorDashboard />);
      expect(await screen.findByText('Fehler beim Laden der Kursdaten.')).toBeInTheDocument();
    });

    it('filtert Kurse basierend auf der Sucheingabe', async () => {
      const mockCourses = [
        { course_id: 1, course_name: 'Mathematik', students: [] },
        { course_id: 2, course_name: 'Informatik', students: [] },
      ];

      mock
        .onGet('http://localhost:5001/instructor/courses?username=s064450330')
        .reply(200, mockCourses);

      render(<InstructorDashboard />);
      const searchInput = await screen.findByPlaceholderText('Suche nach Kursname');
      fireEvent.change(searchInput, { target: { value: 'Mathe' } });

      expect(await screen.findByText('Mathematik')).toBeInTheDocument();
      expect(screen.queryByText('Informatik')).not.toBeInTheDocument();
    });

    it('zeigt Studenten an, wenn ein Kurs ausgewählt wird', async () => {
      const mockCourses = [
        {
          course_id: 1,
          course_name: 'Mathematik',
          students: [{ student_id: 1, name: 'Max Mustermann' }],
        },
      ];

      mock
        .onGet('http://localhost:5001/instructor/courses?username=s064450330')
        .reply(200, mockCourses);

      render(<InstructorDashboard />);
      const course = await screen.findByText('Mathematik');
      fireEvent.click(course);

      expect(await screen.findByText('Max Mustermann')).toBeInTheDocument();
    });
  });

  // -------------------------
  // Tests für StudentDashboard
  // -------------------------
  describe('StudentDashboard', () => {
    it('zeigt die Liste der Kurse an', async () => {
      const mockCourses = [
        { course_id: 1, course_name: 'Mathematik' },
        { course_id: 2, course_name: 'Informatik' },
      ];

      mock
        .onGet('http://localhost:5001/student/courses?username=s054450334')
        .reply(200, mockCourses);

      render(<StudentDashboard />);
      expect(await screen.findByText('Mathematik')).toBeInTheDocument();
      expect(await screen.findByText('Informatik')).toBeInTheDocument();
    });

    it('zeigt eine Fehlermeldung an, wenn das Laden der Kurse fehlschlägt', async () => {
      mock
        .onGet('http://localhost:5001/student/courses?username=s054450334')
        .reply(500);

      render(<StudentDashboard />);
      expect(await screen.findByText('Fehler beim Laden der Kurse.')).toBeInTheDocument();
    });

    it('filtert Kurse basierend auf der Sucheingabe', async () => {
      const mockCourses = [
        { course_id: 1, course_name: 'Mathematik' },
        { course_id: 2, course_name: 'Informatik' },
      ];

      mock
        .onGet('http://localhost:5001/student/courses?username=s054450334')
        .reply(200, mockCourses);

      render(<StudentDashboard />);
      const searchInput = await screen.findByPlaceholderText('Suche nach Kursname');
      fireEvent.change(searchInput, { target: { value: 'Mathe' } });

      expect(await screen.findByText('Mathematik')).toBeInTheDocument();
      expect(screen.queryByText('Informatik')).not.toBeInTheDocument();
    });

    it('zeigt Übungen an, wenn ein Kurs ausgewählt wird', async () => {
      const mockCourses = [
        {
          course_id: 1,
          course_name: 'Mathematik',
          students: [
            {
              student_id: 1,
              name: 'Max Mustermann',
              exercises: [{ exercise_id: 1, title: 'Übung 1' }],
            },
          ],
        },
      ];

      mock
        .onGet('http://localhost:5001/student/courses?username=s054450334')
        .reply(200, mockCourses);

      render(<StudentDashboard />);
      const course = await screen.findByText('Mathematik');
      fireEvent.click(course);

      const exercise = await screen.findByText('Übung 1');
      expect(exercise).toBeInTheDocument();
    });
  });
});
