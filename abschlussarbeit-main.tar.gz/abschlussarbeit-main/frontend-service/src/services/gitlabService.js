import axios from 'axios';

const BASE_URL = "https://dummyjson.com/c/20a4-c052-4c16-ad72"; // Passe die URL an dein Backend an

// Axios-Instanz für Backend-Anfragen
const backendApi = axios.create({
  baseURL: BASE_URL,
});

// Abrufen des Projekts "Abo"
export const getProject = async () => {
  try {
    const response = await backendApi.get('/project');
    return response.data; 
  } catch (error) {
    console.error('Fehler beim Abrufen des Projekts:', error);
    throw error;
  }
};

// Abrufen der Merge Requests des Projekts "Abo"
export const getMergeRequests = async () => {
  try {
    const response = await backendApi.get('/merge_requests');
    return response.data;
  } catch (error) {
    console.error('Fehler beim Abrufen der Merge Requests:', error);
    throw error;
  }
};

// Abrufen von Feedback (Kommentare) für einen Merge Request im Projekt "Abo"
export const getMergeRequestComments = async (mergeRequestId) => {
  try {
    const response = await backendApi.get(`/merge_requests/${mergeRequestId}/comments`);
    return response.data;
  } catch (error) {
    console.error('Fehler beim Abrufen des Feedbacks:', error);
    throw error;
  }
};

// Abrufen aller Pipelines des Projekts "Abo"
export const getPipelines = async () => {
  try {
    const response = await backendApi.get('/pipelines');
    return response.data;
  } catch (error) {
    console.error('Fehler beim Abrufen der Pipelines:', error);
    throw error;
  }
};

// Abrufen einer spezifischen Pipeline des Projekts "Abo"
export const getPipeline = async (pipelineId) => {
  try {
    const response = await backendApi.get(`/pipelines/${pipelineId}`);
    return response.data;
  } catch (error) {
    console.error('Fehler beim Abrufen der Pipeline:', error);
    throw error;
  }
};

// Abrufen aller Jobs einer Pipeline im Projekt "Abo"
export const getPipelineJobs = async (pipelineId) => {
  try {
    const response = await backendApi.get(`/pipelines/${pipelineId}/jobs`);
    return response.data;
  } catch (error) {
    console.error('Fehler beim Abrufen der Pipeline Jobs:', error);
    throw error;
  }
};

// Abrufen eines spezifischen Jobs einer Pipeline im Projekt "Abo"
export const getJob = async (pipelineId, jobId) => {
  try {
    const response = await backendApi.get(`/pipelines/${pipelineId}/jobs/${jobId}`);
    return response.data;
  } catch (error) {
    console.error('Fehler beim Abrufen des Jobs:', error);
    throw error;
  }
};