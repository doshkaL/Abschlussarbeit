import axios from 'axios';

// Basis-URL des Backend-Servers
const API_URL = 'http://localhost:5001';

// Authentifizierungstoken aus dem LocalStorage holen
const getAuthToken = () => {
  return localStorage.getItem('token');
};

// Instanz von Axios erstellen
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});


// Interceptor für das Hinzufügen des Tokens zu den Anfragen
api.interceptors.request.use((config) => {
  const token = getAuthToken();
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`;
  }
  return config;
});

// API-Aufrufe definieren
export const login = async (username, password) => {
  const response = await api.post('/login', { username, password });
  return response.data;
};



export const getCourses = async () => {
  const response = await api.get('/get_courses');
  return response.data;
};

export const getFeedback = async (userId) => {
  const response = await api.get(`/get_feedback/${userId}`);
  return response.data;
};

export const submitFeedback = async (userId, feedback) => {
  const response = await api.post('/submit_feedback', { user_id: userId, feedback });
  return response.data;
};
