import axios from "axios";

const API_URL = "http://localhost:5000"; // URL deines Login-Service (Python)

export const login = async (matriculationNumber, password) => {
  try {
    const response = await axios.post(`${API_URL}/login`, {
      matriculation_number: matriculationNumber,
      password: password,
    });
    return response.data; // Token oder User-Details
  } catch (error) {
    console.error("Login error:", error.response?.data || error.message);
    throw error;
  }
};

export const getUserDetails = async (token) => {
  try {
    const response = await axios.get(`${API_URL}/user`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data; // User-Details
  } catch (error) {
    console.error("User details error:", error.response?.data || error.message);
    throw error;
  }
};
