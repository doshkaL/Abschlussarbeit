import React from "react";
import { Link } from "react-router-dom";

const HomePage = () => {
  return (
    <div>
      <h1>Willkommen</h1>
      <Link to="/login">Login</Link>
      <Link to="/dashbord">dashbord</Link>
    </div>
  );
};

export default HomePage;
