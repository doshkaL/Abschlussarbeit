import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import CourseList from "../components/InstructorComponent/CourseList";
import StudentList from "../components/InstructorComponent/StudentList";
import StudentDetails from "../components/InstructorComponent/StudentDetails";
import FeedbackCard from "../components/InstructorComponent/FeedbackCard";

const InstructorDashboard = () => {
  const [courses, setCourses] = useState([]);
  const [filteredCourses, setFilteredCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [searchCourse, setSearchCourse] = useState("");
  const [searchStudent, setSearchStudent] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [selectedExercise, setSelectedExercise] = useState(null);

  const navigate = useNavigate();

  // Überprüfung, ob der Benutzer eingeloggt ist
  useEffect(() => {
    const role = localStorage.getItem("role");
    const username = localStorage.getItem("username");

    if (!username || role !== "student") {
      navigate("/login");
      return;
    }

    const fetchData = async () => {
      setLoading(true);
      try {
        const response = await axios.get(
          `http://localhost:5001/instructor/courses?username=${username}`
        
        );
        setCourses(response.data);
        setFilteredCourses(response.data);
      } catch (err) {
        console.error("Fehler beim Laden der Daten:", err);
        setError("Fehler beim Laden der Kursdaten.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [navigate]);

   // Falls kein username vorhanden ist, keine Daten anzeigen
   if (!localStorage.getItem("username")) {
    return null;
  }

  // Kurs-Suche
  const handleCourseSearch = (e) => {
    const searchValue = e.target.value.toLowerCase();
    setSearchCourse(searchValue);
    setFilteredCourses(
      courses.filter((course) =>
        course.course_name.toLowerCase().includes(searchValue)
      )
    );
  };

  // Student-Suche
  const handleStudentSearch = (e) => {
    const searchValue = e.target.value.toLowerCase();
    setSearchStudent(searchValue);
  };

  // Kurs-Auswahl
  const handleCourseClick = (course) => {
    setSelectedCourse(course);
    setSelectedStudent(null);
  };

  // Übungs-Feedback anzeigen
  const handleFeedbackClick = (exercise) => {
    setSelectedExercise(exercise);
  };

  // Zurück zu den Kursen
  const handleBackToCourses = () => {
    setSelectedCourse(null);
    setSelectedStudent(null);
  };

  // Logout
  const handleLogout = () => {
    localStorage.removeItem("role");
    localStorage.removeItem("username");
    navigate("/login");
  };

  // Ladeanzeige
  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p className="text-gray-700 font-semibold text-lg">Daten werden geladen...</p>
      </div>
    );
  }

  // Fehleranzeige
  if (error) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p className="text-red-600 font-semibold text-lg">{error}</p>
      </div>
    );
  }

  return (
    <div className="flex-grow bg-gray-100">
      <div className="w-full px-4 py-8">
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex justify-between">
            <h1
              className="text-3xl lg:text-4xl font-bold mb-6"
              style={{ color: "#76B900" }}
            >
              Dozenten Dashboard
            </h1>
            <button
              onClick={handleLogout}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
            >
              Logout
            </button>
          </div>
          <p className="text-gray-600 mb-6">
            Verwalten Sie Kurse, Studenten und deren Ergebnisse.
          </p>

          {selectedCourse === null ? (
            <CourseList
              courses={filteredCourses}
              searchCourse={searchCourse}
              handleCourseSearch={handleCourseSearch}
              selectedCourse={selectedCourse}
              setSelectedCourse={setSelectedCourse}
              handleCourseClick={handleCourseClick}
            />
          ) : (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-semibold text-gray-700">
                  Studenten für {selectedCourse.course_name}
                </h3>
                <button
                  className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  onClick={handleBackToCourses}
                >
                  Zurück zu den Kursen
                </button>
              </div>
              <StudentList
                students={selectedCourse.students}
                searchStudent={searchStudent}
                handleStudentSearch={handleStudentSearch}
                setSelectedStudent={setSelectedStudent}
                selectedCourse={selectedCourse}
              />
              {selectedStudent && (
                <StudentDetails
                  student={selectedStudent}
                  onFeedbackClick={handleFeedbackClick}
                />
              )}
            </div>
          )}
        </div>

        {selectedExercise && (
          <div className="fixed top-0 left-0 w-full h-full bg-gray-900 bg-opacity-50 flex items-center justify-center">
            <div className="w-full max-w-lg bg-white rounded-lg p-6">
              <FeedbackCard
                exercise={selectedExercise}
                onReturn={() => setSelectedExercise(null)}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default InstructorDashboard;
