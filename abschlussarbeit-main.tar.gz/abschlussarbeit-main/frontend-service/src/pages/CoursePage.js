import React, { useState, useEffect } from 'react';
import { getFeedback, submitFeedback } from './services/api';
import { useParams } from 'react-router-dom';

function CoursePage() {
  const [feedback, setFeedback] = useState('');
  const [existingFeedback, setExistingFeedback] = useState([]);
  const { courseId } = useParams();

  useEffect(() => {
    const fetchFeedback = async () => {
      const feedbackData = await getFeedback(courseId);
      setExistingFeedback(feedbackData);
    };
    fetchFeedback();
  }, [courseId]);

  const handleFeedbackSubmit = async () => {
    await submitFeedback(courseId, feedback);
    setFeedback('');
    alert('Feedback submitted successfully!');
  };

  return (
    <div>
      <h2>Course {courseId}</h2>
      <h3>Existing Feedback</h3>
      <ul>
        {existingFeedback.map((f, index) => (
          <li key={index}>{f.feedback}</li>
        ))}
      </ul>
      <h3>Submit Feedback</h3>
      <textarea
        value={feedback}
        onChange={(e) => setFeedback(e.target.value)}
      />
      <button onClick={handleFeedbackSubmit}>Submit Feedback</button>
    </div>
  );
}

export default CoursePage;
