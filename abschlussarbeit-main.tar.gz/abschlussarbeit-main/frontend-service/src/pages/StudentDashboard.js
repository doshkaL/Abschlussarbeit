import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import CourseList from "../components/StudentComponents/CourseList";
import ExerciseList from "../components/StudentComponents/ExerciseList";
import StudentFeedbackCard from "../components/StudentComponents/StudentFeedbackCard";

const StudentDashboard = () => {
  const [courses, setCourses] = useState([]);
  const [filteredCourses, setFilteredCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [exercises, setExercises] = useState([]);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);
  const [selectedExercise, setSelectedExercise] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const role = localStorage.getItem("role");
    const username = localStorage.getItem("username");

    if (!username || role !== "student") {
      navigate("/login");
      return;
    }

    const fetchCourses = async () => {
      setLoading(true);
      try {
        const response = await axios.get(`http://localhost:5001/student/courses?username=${username}`);
        setCourses(response.data);
        setFilteredCourses(response.data);
      } catch (err) {
        console.error("Fehler beim Laden der Kurse:", err);
        setError("Fehler beim Laden der Kurse.");
      } finally {
        setLoading(false);
      }
    };
    fetchCourses();
  }, [navigate]);

  if (!localStorage.getItem("username")) return null;

  const handleSearch = (event) => {
    const term = event.target.value.toLowerCase();
    setSearchTerm(term);
    setFilteredCourses(courses.filter((course) => course.course_name.toLowerCase().includes(term)));
    setCurrentPage(1);
  };

  const handleCourseSelect = (courseId) => {
    const selected = courses.find((course) => course.course_id === courseId);
    if (selected) {
      setSelectedCourse(selected.course_name);
      setExercises(selected.students[0]?.exercises || []);
    }
  };

  const handleFeedbackClick = (exercise) => setSelectedExercise(exercise);
  const handleBackToCourses = () => { setSelectedCourse(null); setExercises([]); };

  const handleLogout = () => {
    localStorage.removeItem("role");
    localStorage.removeItem("username");
    navigate("/login");
  };

  const totalPages = Math.ceil(filteredCourses.length / itemsPerPage);
  const paginatedCourses = filteredCourses.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  if (loading) return <div className="flex justify-center items-center min-h-screen"><p className="text-gray-700 font-semibold text-lg">Daten werden geladen...</p></div>;
  if (error) return <div className="flex justify-center items-center min-h-screen"><p className="text-red-600 font-semibold text-lg">{error}</p></div>;

  return (
    <div className="flex-grow bg-gray-100">
      <div className="w-full px-4 py-8">
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex justify-between">
            <h1 className="text-3xl lg:text-4xl font-bold mb-6" style={{ color: "#76B900" }}>Student Dashboard</h1>
            <button onClick={handleLogout} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">Logout</button>
          </div>
          <p className="text-gray-600 mb-6">Verwalten Sie Ihre Kurse und Übungen.</p>
          {!selectedCourse ? (
            <>
              <input type="text" placeholder="Suche nach Kursname" value={searchTerm} onChange={handleSearch} className="mb-6 p-3 border rounded w-full max-w-lg mx-auto block" />
              <CourseList courses={paginatedCourses} onSelect={handleCourseSelect} />
              <div className="flex justify-center space-x-2 mt-4">
                {[...Array(totalPages)].map((_, index) => (
                  <button key={index} className={`px-4 py-2 border rounded ${currentPage === index + 1 ? "bg-blue-500 text-white" : "bg-gray-200"}`} 
                  onClick={() => setCurrentPage(index + 1)}>{index + 1}</button>
                ))}
              </div>
            </>
          ) : (
            <ExerciseList exercises={exercises} courseName={selectedCourse} onFeedbackClick={handleFeedbackClick} onReturn={handleBackToCourses} />
          )}
        </div>
        {selectedExercise && (
          <div className="fixed top-0 left-0 w-full h-full bg-gray-900 bg-opacity-50 flex items-center justify-center">
            <div className="w-full max-w-lg bg-white rounded-lg p-6">
              <StudentFeedbackCard exercise={selectedExercise} onReturn={() => setSelectedExercise(null)} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentDashboard;
